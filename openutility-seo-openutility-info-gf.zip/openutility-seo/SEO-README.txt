OpenUtility SEO pages

This bundle creates one static SEO landing page per existing tool:
  /tools/<tool-id>/

Replace https://openutility.info.gf in sitemap.xml, robots.txt, and the generated
tool pages with the real production domain before publishing.

Each page contains:
- unique title and meta description
- canonical URL
- Open Graph/Twitter metadata
- WebApplication JSON-LD
- useful explanatory copy and FAQ
- related-tool links
- link into the existing OpenUtility app with ?tool=<tool-id>

The actual interactive tool remains in the main app. The SEO pages are the
search-friendly entry points.
